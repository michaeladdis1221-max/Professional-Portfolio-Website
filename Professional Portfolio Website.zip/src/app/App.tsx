import { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence, useScroll, useSpring } from "motion/react";
import {
  Github, Linkedin, Instagram, Mail, Phone, MapPin,
  ExternalLink, ChevronDown, Menu, X, Moon, Sun,
  Code2, Zap, Globe, Star, ArrowUp, Search,
  Download, Eye, BookOpen, Briefcase, Heart,
  MessageCircle, Layers, Palette, Smartphone,
  CheckCircle, Send, ArrowRight, Monitor,
} from "lucide-react";

// ─── INJECTED STYLES ──────────────────────────────────────────────────────────
const STYLES = `
  @media (hover: hover) { * { cursor: none !important; } }

  body { font-family: 'Inter', sans-serif; overflow-x: hidden; scroll-behavior: smooth; }
  h1,h2,h3,h4,h5,h6 { font-family: 'Outfit', sans-serif; }

  .cur-dot {
    width: 8px; height: 8px; border-radius: 50%;
    background: #7c3aed; position: fixed; pointer-events: none;
    z-index: 9999; transform: translate(-50%,-50%);
    transition: width .15s, height .15s, background .15s;
  }
  .cur-ring {
    width: 38px; height: 38px; border-radius: 50%;
    border: 1.5px solid rgba(124,58,237,.5);
    position: fixed; pointer-events: none; z-index: 9998;
    transform: translate(-50%,-50%);
  }

  .grad-text {
    background: linear-gradient(135deg, #a78bfa 10%, #22d3ee 90%);
    -webkit-background-clip: text; -webkit-text-fill-color: transparent;
    background-clip: text;
  }

  .grad-border {
    position: relative;
  }
  .grad-border::before {
    content: ''; position: absolute; inset: 0;
    border-radius: inherit; padding: 1.5px;
    background: linear-gradient(135deg, #7c3aed, #22d3ee);
    -webkit-mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
    -webkit-mask-composite: xor; mask-composite: exclude;
    pointer-events: none;
  }

  .glass {
    background: rgba(255,255,255,.045);
    backdrop-filter: blur(20px); -webkit-backdrop-filter: blur(20px);
    border: 1px solid rgba(255,255,255,.08);
  }
  :root:not(.dark) .glass {
    background: rgba(255,255,255,.7);
    border: 1px solid rgba(0,0,0,.07);
  }

  .glass-card {
    background: rgba(255,255,255,.04);
    backdrop-filter: blur(16px);
    border: 1px solid rgba(255,255,255,.07);
    border-radius: 1.25rem;
    transition: border-color .3s, box-shadow .3s, transform .3s;
  }
  :root:not(.dark) .glass-card {
    background: rgba(255,255,255,.85);
    border: 1px solid rgba(0,0,0,.07);
    box-shadow: 0 4px 24px rgba(0,0,0,.04);
  }
  .glass-card:hover {
    border-color: rgba(124,58,237,.35);
    box-shadow: 0 20px 60px rgba(124,58,237,.12);
    transform: translateY(-5px);
  }

  .hero-glow {
    background:
      radial-gradient(ellipse 60% 60% at 20% 50%, rgba(124,58,237,.18) 0%, transparent 70%),
      radial-gradient(ellipse 50% 50% at 80% 20%, rgba(34,211,238,.1) 0%, transparent 65%),
      radial-gradient(ellipse 40% 40% at 50% 90%, rgba(124,58,237,.1) 0%, transparent 65%);
  }

  @keyframes float { 0%,100%{transform:translateY(0)} 50%{transform:translateY(-18px)} }
  @keyframes ping-slow { 0%{transform:scale(1);opacity:.6} 100%{transform:scale(1.7);opacity:0} }
  @keyframes load-bar { 0%{width:0} 60%{width:75%} 100%{width:100%} }
  @keyframes blink { 0%,100%{opacity:1} 50%{opacity:0} }

  .floating { animation: float 7s ease-in-out infinite; }
  .blink { animation: blink 1s step-end infinite; }
  .ping-slow { animation: ping-slow 2s ease-out infinite; }

  .load-bar-fill {
    height:100%; border-radius: 999px;
    background: linear-gradient(90deg,#7c3aed,#22d3ee);
    animation: load-bar 2.6s cubic-bezier(.4,0,.2,1) forwards;
  }

  .btn-primary {
    display: inline-flex; align-items: center; gap: .5rem;
    background: linear-gradient(135deg,#7c3aed,#22d3ee);
    color: #fff; border: none; padding: .75rem 1.75rem;
    border-radius: .75rem; font-weight: 600; font-size: .9rem;
    font-family: 'Outfit', sans-serif;
    cursor: pointer; transition: transform .25s, box-shadow .25s;
    position: relative; overflow: hidden;
  }
  .btn-primary::before {
    content: ''; position: absolute; inset: 0;
    background: linear-gradient(135deg,#6d28d9,#0891b2);
    opacity: 0; transition: opacity .25s;
  }
  .btn-primary:hover::before { opacity: 1; }
  .btn-primary:hover { transform: translateY(-2px); box-shadow: 0 12px 40px rgba(124,58,237,.4); }
  .btn-primary > * { position: relative; z-index: 1; }

  .btn-ghost {
    display: inline-flex; align-items: center; gap: .5rem;
    background: rgba(124,58,237,.08); color: #a78bfa;
    border: 1.5px solid rgba(124,58,237,.35);
    padding: .75rem 1.75rem; border-radius: .75rem;
    font-weight: 600; font-size: .9rem; font-family: 'Outfit', sans-serif;
    cursor: pointer; transition: all .25s;
  }
  .btn-ghost:hover {
    background: rgba(124,58,237,.16); border-color: rgba(124,58,237,.6);
    transform: translateY(-2px);
  }

  .nav-link {
    position: relative; font-size: .875rem; font-weight: 500;
    letter-spacing: .02em;
    color: rgba(240,240,250,.6);
    transition: color .2s; text-decoration: none;
  }
  .nav-link::after {
    content: ''; position: absolute; bottom: -3px; left: 0;
    width: 0; height: 1.5px;
    background: linear-gradient(90deg,#7c3aed,#22d3ee);
    transition: width .3s ease;
  }
  .nav-link:hover, .nav-link.active { color: #f0f0fa; }
  .nav-link:hover::after, .nav-link.active::after { width: 100%; }
  :root:not(.dark) .nav-link { color: rgba(15,15,26,.55); }
  :root:not(.dark) .nav-link:hover, :root:not(.dark) .nav-link.active { color: #0f0f1a; }

  .skill-bar {
    height: 6px; border-radius: 999px;
    background: rgba(255,255,255,.08); overflow: hidden;
  }
  :root:not(.dark) .skill-bar { background: rgba(0,0,0,.07); }
  .skill-fill {
    height: 100%; border-radius: 999px;
    background: linear-gradient(90deg,#7c3aed,#22d3ee);
    transition: width 1.4s cubic-bezier(.22,1,.36,1);
  }

  .tag {
    display: inline-flex; align-items: center;
    padding: .2rem .65rem; border-radius: 999px;
    font-size: .72rem; font-weight: 500; letter-spacing: .03em;
    background: rgba(124,58,237,.14); color: #c4b5fd;
    border: 1px solid rgba(124,58,237,.22);
    font-family: 'JetBrains Mono', monospace;
  }
  :root:not(.dark) .tag {
    background: rgba(124,58,237,.08); color: #6d28d9;
    border-color: rgba(124,58,237,.18);
  }

  .timeline-line {
    width: 1px; flex: 1; margin-top: .5rem;
    background: linear-gradient(180deg, rgba(124,58,237,.4), transparent);
  }
  .tl-dot {
    width: 14px; height: 14px; border-radius: 50%; flex-shrink: 0;
    background: linear-gradient(135deg,#7c3aed,#22d3ee);
    position: relative;
  }
  .tl-dot::after {
    content: ''; position: absolute; inset: -5px; border-radius: 50%;
    background: rgba(124,58,237,.25); animation: ping-slow 2.5s ease-out infinite;
  }

  .proj-img { width:100%; height:200px; object-fit:cover; transition:transform .5s ease; }
  .proj-card:hover .proj-img { transform: scale(1.06); }

  .section-label {
    font-family: 'JetBrains Mono', monospace;
    font-size: .72rem; letter-spacing: .2em; text-transform: uppercase;
    color: #7c3aed;
  }

  .scroll-progress {
    position: fixed; top: 0; left: 0; right: 0; height: 3px;
    background: linear-gradient(90deg,#7c3aed,#22d3ee);
    transform-origin: 0%; z-index: 9997;
  }

  ::-webkit-scrollbar { width: 5px; }
  ::-webkit-scrollbar-track { background: transparent; }
  ::-webkit-scrollbar-thumb { background: rgba(124,58,237,.3); border-radius: 3px; }
  ::-webkit-scrollbar-thumb:hover { background: rgba(124,58,237,.55); }

  .divider {
    width: 48px; height: 3px; border-radius: 2px; margin: .75rem auto 1.5rem;
    background: linear-gradient(90deg,#7c3aed,#22d3ee);
  }

  .contact-input {
    width: 100%;
    background: rgba(255,255,255,.05); border: 1px solid rgba(255,255,255,.08);
    border-radius: .75rem; padding: .75rem 1rem;
    color: #f0f0fa; font-size: .9rem; font-family: 'Inter', sans-serif;
    outline: none; transition: border-color .2s, background .2s;
  }
  .contact-input::placeholder { color: rgba(240,240,250,.25); }
  .contact-input:focus { border-color: rgba(124,58,237,.5); background: rgba(255,255,255,.07); }
  :root:not(.dark) .contact-input {
    background: rgba(0,0,0,.03); border-color: rgba(0,0,0,.08); color: #0f0f1a;
  }
  :root:not(.dark) .contact-input::placeholder { color: rgba(15,15,26,.3); }
  :root:not(.dark) .contact-input:focus { border-color: rgba(124,58,237,.4); background: rgba(124,58,237,.03); }
`;

// ─── DATA ─────────────────────────────────────────────────────────────────────

const NAV_LINKS = [
  { label: "Home", href: "#hero" },
  { label: "About", href: "#about" },
  { label: "Skills", href: "#skills" },
  { label: "Projects", href: "#projects" },
  { label: "Services", href: "#services" },
  { label: "Contact", href: "#contact" },
];

const TYPED = [
  "Building Modern Digital Experiences.",
  "Turning Ideas Into Reality.",
  "Creating Beautiful User Interfaces.",
  "Crafting Responsive Websites.",
];

const SKILLS_DATA = {
  "Frontend": [
    { name: "HTML5", pct: 95 },
    { name: "CSS3", pct: 90 },
    { name: "JavaScript", pct: 85 },
    { name: "TypeScript", pct: 75 },
    { name: "React", pct: 80 },
  ],
  "Backend": [
    { name: "Node.js", pct: 65 },
    { name: "Express", pct: 62 },
    { name: "PHP", pct: 50 },
    { name: "Python", pct: 55 },
  ],
  "Tools & Design": [
    { name: "GitHub", pct: 88 },
    { name: "VS Code", pct: 95 },
    { name: "Netlify", pct: 78 },
    { name: "Figma", pct: 70 },
  ],
};

const PROJECTS_DATA = [
  {
    id: 1, title: "Addis Cafe & Restaurant",
    desc: "A full-featured restaurant website with responsive design, dark mode toggle, smooth animations, and bilingual Amharic/English support.",
    img: "https://images.unsplash.com/photo-1555396273-367ea4eb4db5?w=600&h=400&fit=crop&auto=format",
    tech: ["HTML", "CSS", "JavaScript"], cat: "Frontend", stars: 12,
    github: "https://github.com/MichaelAddisu", demo: "#",
  },
  {
    id: 2, title: "Developer Portfolio V2",
    desc: "An award-worthy portfolio with GSAP animations, Framer Motion transitions, glassmorphism UI, and a custom cursor system.",
    img: "https://images.unsplash.com/photo-1461749280684-dccba630e2f6?w=600&h=400&fit=crop&auto=format",
    tech: ["React", "TypeScript", "GSAP"], cat: "React", stars: 24,
    github: "https://github.com/MichaelAddisu", demo: "#",
  },
  {
    id: 3, title: "Weather Application",
    desc: "Real-time weather tracking with OpenWeather API integration, dynamic animated backgrounds, and location-based search.",
    img: "https://images.unsplash.com/photo-1504608524841-42584120d497?w=600&h=400&fit=crop&auto=format",
    tech: ["JavaScript", "REST API"], cat: "JavaScript", stars: 8,
    github: "https://github.com/MichaelAddisu", demo: "#",
  },
  {
    id: 4, title: "Todo Application",
    desc: "Feature-rich task manager with localStorage persistence, drag-and-drop, categories, and deadline tracking.",
    img: "https://images.unsplash.com/photo-1484480974693-6ca0a78fb36b?w=600&h=400&fit=crop&auto=format",
    tech: ["HTML", "CSS", "JavaScript"], cat: "Frontend", stars: 6,
    github: "https://github.com/MichaelAddisu", demo: "#",
  },
  {
    id: 5, title: "E-Commerce Platform",
    desc: "Full-stack shopping platform with cart management, JWT authentication, admin dashboard, and Stripe payment.",
    img: "https://images.unsplash.com/photo-1563013544-824ae1b704d3?w=600&h=400&fit=crop&auto=format",
    tech: ["React", "Node.js", "Express"], cat: "Fullstack", stars: 19,
    github: "https://github.com/MichaelAddisu", demo: "#",
  },
  {
    id: 6, title: "Blog Platform",
    desc: "Modern blogging platform with Markdown support, category filtering, full-text search, and seamless dark mode.",
    img: "https://images.unsplash.com/photo-1499750310107-5fef28a66643?w=600&h=400&fit=crop&auto=format",
    tech: ["React"], cat: "React", stars: 11,
    github: "https://github.com/MichaelAddisu", demo: "#",
  },
];

const CATS = ["All", "Frontend", "React", "JavaScript", "Fullstack"];

const SERVICES_DATA = [
  { icon: Monitor, title: "Front-End Development", desc: "Pixel-perfect, performant interfaces built with modern React and TypeScript." },
  { icon: Globe, title: "Web Development", desc: "Complete web solutions—from static sites to full-stack applications." },
  { icon: Smartphone, title: "Responsive Design", desc: "Flawless layouts across every device, viewport, and orientation." },
  { icon: Zap, title: "Landing Pages", desc: "High-converting landing pages crafted to impress and drive results." },
  { icon: Palette, title: "UI/UX Design", desc: "Beautiful, user-first designs prototyped and refined in Figma." },
  { icon: Layers, title: "Portfolio Websites", desc: "Stunning personal portfolios that make you stand out from the crowd." },
];

const STATS_DATA = [
  { label: "Projects Completed", val: 20, icon: Briefcase, suffix: "+" },
  { label: "Happy Clients", val: 15, icon: Heart, suffix: "+" },
  { label: "Technologies", val: 12, icon: Code2, suffix: "+" },
  { label: "Years of Learning", val: 2, icon: BookOpen, suffix: "+" },
];

const TESTIMONIALS_DATA = [
  { name: "Abebe Girma", role: "Startup Founder", rating: 5, avatar: "AG", text: "Michael delivered an exceptional website that exceeded all expectations. His attention to detail and creativity are simply unmatched." },
  { name: "Sara Tadesse", role: "Restaurant Owner", rating: 5, avatar: "ST", text: "The website Michael built for Addis Cafe is absolutely stunning. Our online presence and customer engagement have never been better!" },
  { name: "Yonas Bekele", role: "Entrepreneur", rating: 5, avatar: "YB", text: "Professional, creative, and incredibly talented. Michael turned our vision into a beautiful digital reality, on time and on budget." },
  { name: "Hana Alemu", role: "NGO Director", rating: 5, avatar: "HA", text: "Working with Michael was an absolute pleasure. He understood our needs perfectly and delivered far beyond what we imagined." },
];

const BLOG_DATA = [
  { title: "Mastering CSS Grid for Modern Layouts", cat: "CSS", date: "June 2025", read: "5 min", img: "https://images.unsplash.com/photo-1507721999472-8ed4421c4af2?w=600&h=400&fit=crop&auto=format" },
  { title: "React Hooks: A Practical Deep Dive", cat: "React", date: "May 2025", read: "8 min", img: "https://images.unsplash.com/photo-1633356122544-f134324a6cee?w=600&h=400&fit=crop&auto=format" },
  { title: "JavaScript Performance Optimization", cat: "JavaScript", date: "Apr 2025", read: "6 min", img: "https://images.unsplash.com/photo-1579468118864-1b9ea3c0db4a?w=600&h=400&fit=crop&auto=format" },
];

const TIMELINE_DATA = [
  { year: "2022", title: "Started Learning Web Dev", desc: "Began the journey with HTML, CSS, and JavaScript fundamentals from scratch." },
  { year: "2023", title: "First React Project", desc: "Built my first React application and fell in love with component-based architecture." },
  { year: "2024", title: "Expanded to Full Stack", desc: "Learned Node.js and Express, building complete end-to-end web applications." },
  { year: "2025", title: "Professional Freelancing", desc: "Started taking professional client projects across Ethiopia, delivering real impact." },
];

// ─── HOOKS ────────────────────────────────────────────────────────────────────

function useTyping(strings: string[], speed = 80, pause = 2200) {
  const [text, setText] = useState("");
  const [si, setSi] = useState(0);
  const [ci, setCi] = useState(0);
  const [del, setDel] = useState(false);

  useEffect(() => {
    const cur = strings[si];
    let t: ReturnType<typeof setTimeout>;
    if (!del) {
      if (ci < cur.length) {
        t = setTimeout(() => { setText(cur.slice(0, ci + 1)); setCi(n => n + 1); }, speed);
      } else {
        t = setTimeout(() => setDel(true), pause);
      }
    } else {
      if (ci > 0) {
        t = setTimeout(() => { setText(cur.slice(0, ci - 1)); setCi(n => n - 1); }, speed / 2);
      } else {
        setDel(false);
        setSi(n => (n + 1) % strings.length);
      }
    }
    return () => clearTimeout(t);
  }, [ci, del, si, strings, speed, pause]);

  return text;
}

function useInView(threshold = 0.2) {
  const ref = useRef<HTMLDivElement>(null);
  const [vis, setVis] = useState(false);
  useEffect(() => {
    const ob = new IntersectionObserver(([e]) => { if (e.isIntersecting) { setVis(true); ob.disconnect(); } }, { threshold });
    if (ref.current) ob.observe(ref.current);
    return () => ob.disconnect();
  }, [threshold]);
  return { ref, vis };
}

function useCounter(target: number, active: boolean, dur = 2000) {
  const [n, setN] = useState(0);
  useEffect(() => {
    if (!active) return;
    let cur = 0;
    const step = target / (dur / 16);
    const id = setInterval(() => {
      cur += step;
      if (cur >= target) { setN(target); clearInterval(id); }
      else setN(Math.floor(cur));
    }, 16);
    return () => clearInterval(id);
  }, [target, active, dur]);
  return n;
}

// ─── ANIMATION VARIANTS ───────────────────────────────────────────────────────

const fadeUp = {
  hidden: { opacity: 0, y: 36 },
  show: { opacity: 1, y: 0, transition: { duration: 0.6, ease: [0.22, 1, 0.36, 1] } },
};

const stagger = {
  hidden: {},
  show: { transition: { staggerChildren: 0.08 } },
};

// ─── SMALL COMPONENTS ─────────────────────────────────────────────────────────

const MALogo = () => (
  <svg width="44" height="44" viewBox="0 0 44 44" fill="none" aria-label="MA Logo">
    <defs>
      <linearGradient id="lg" x1="0" y1="0" x2="44" y2="44" gradientUnits="userSpaceOnUse">
        <stop stopColor="#7c3aed" />
        <stop offset="1" stopColor="#22d3ee" />
      </linearGradient>
    </defs>
    <rect width="44" height="44" rx="10" fill="url(#lg)" />
    <path d="M12 30 L18 15 L22 25 L26 15 L32 30" stroke="white" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" fill="none" />
  </svg>
);

const SectionHeader = ({ label, title, desc }: { label: string; title: string; desc?: string }) => (
  <div className="text-center mb-16">
    <motion.p variants={fadeUp} initial="hidden" whileInView="show" viewport={{ once: true }} className="section-label mb-2">
      — {label} —
    </motion.p>
    <motion.h2
      variants={fadeUp} initial="hidden" whileInView="show" viewport={{ once: true }}
      className="grad-text font-bold text-4xl md:text-5xl mb-3 leading-tight"
    >
      {title}
    </motion.h2>
    <div className="divider" />
    {desc && (
      <motion.p variants={fadeUp} initial="hidden" whileInView="show" viewport={{ once: true }}
        className="text-foreground/50 max-w-2xl mx-auto text-[1rem] leading-relaxed">
        {desc}
      </motion.p>
    )}
  </div>
);

// ─── LOADER ───────────────────────────────────────────────────────────────────

const Loader = ({ onDone }: { onDone: () => void }) => {
  useEffect(() => {
    const t = setTimeout(onDone, 2900);
    return () => clearTimeout(t);
  }, [onDone]);

  return (
    <motion.div
      className="fixed inset-0 z-[9999] flex flex-col items-center justify-center"
      style={{ background: "#070712" }}
      exit={{ opacity: 0, transition: { duration: 0.6, ease: "easeInOut" } }}
    >
      <motion.div
        initial={{ scale: 0.6, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ duration: 0.55, ease: [0.22, 1, 0.36, 1] }}
        className="mb-6"
      >
        <MALogo />
      </motion.div>
      <motion.p
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
        style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: ".72rem", letterSpacing: ".2em", color: "rgba(167,139,250,.7)", marginBottom: "2rem" }}
      >
        LOADING PORTFOLIO...
      </motion.p>
      <div style={{ width: 192, height: 3, background: "rgba(255,255,255,.08)", borderRadius: 999, overflow: "hidden" }}>
        <div className="load-bar-fill" />
      </div>
    </motion.div>
  );
};

// ─── CURSOR ───────────────────────────────────────────────────────────────────

const CustomCursor = () => {
  const dot = useRef<HTMLDivElement>(null);
  const ring = useRef<HTMLDivElement>(null);
  const mouse = useRef({ x: -100, y: -100 });
  const pos = useRef({ x: -100, y: -100 });

  useEffect(() => {
    const onMove = (e: MouseEvent) => {
      mouse.current = { x: e.clientX, y: e.clientY };
      if (dot.current) { dot.current.style.left = e.clientX + "px"; dot.current.style.top = e.clientY + "px"; }
    };
    document.addEventListener("mousemove", onMove);

    let raf: number;
    const follow = () => {
      pos.current.x += (mouse.current.x - pos.current.x) * 0.11;
      pos.current.y += (mouse.current.y - pos.current.y) * 0.11;
      if (ring.current) { ring.current.style.left = pos.current.x + "px"; ring.current.style.top = pos.current.y + "px"; }
      raf = requestAnimationFrame(follow);
    };
    follow();
    return () => { document.removeEventListener("mousemove", onMove); cancelAnimationFrame(raf); };
  }, []);

  return (
    <>
      <div ref={dot} className="cur-dot" />
      <div ref={ring} className="cur-ring" />
    </>
  );
};

// ─── SCROLL PROGRESS ─────────────────────────────────────────────────────────

const ScrollProgress = () => {
  const { scrollYProgress } = useScroll();
  const scaleX = useSpring(scrollYProgress, { stiffness: 120, damping: 30, restDelta: 0.001 });
  return <motion.div className="scroll-progress" style={{ scaleX }} />;
};

// ─── PARTICLE CANVAS ─────────────────────────────────────────────────────────

const ParticleCanvas = () => {
  const ref = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const cv = ref.current;
    if (!cv) return;
    const ctx = cv.getContext("2d");
    if (!ctx) return;
    const resize = () => { cv.width = window.innerWidth; cv.height = window.innerHeight; };
    resize();
    const pts = Array.from({ length: 65 }, () => ({
      x: Math.random() * cv.width, y: Math.random() * cv.height,
      vx: (Math.random() - .5) * .35, vy: (Math.random() - .5) * .35,
      r: Math.random() * 1.4 + .4, o: Math.random() * .45 + .1,
    }));
    let raf: number;
    const draw = () => {
      ctx.clearRect(0, 0, cv.width, cv.height);
      pts.forEach(p => {
        p.x += p.vx; p.y += p.vy;
        if (p.x < 0 || p.x > cv.width) p.vx *= -1;
        if (p.y < 0 || p.y > cv.height) p.vy *= -1;
        ctx.beginPath(); ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(139,92,246,${p.o})`; ctx.fill();
      });
      pts.forEach((a, i) => pts.slice(i + 1).forEach(b => {
        const d = Math.hypot(a.x - b.x, a.y - b.y);
        if (d < 110) {
          ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y);
          ctx.strokeStyle = `rgba(139,92,246,${.12 * (1 - d / 110)})`; ctx.lineWidth = .5; ctx.stroke();
        }
      }));
      raf = requestAnimationFrame(draw);
    };
    draw();
    window.addEventListener("resize", resize);
    return () => { cancelAnimationFrame(raf); window.removeEventListener("resize", resize); };
  }, []);
  return <canvas ref={ref} className="absolute inset-0 pointer-events-none opacity-70" />;
};

// ─── NAVBAR ───────────────────────────────────────────────────────────────────

const Navbar = ({ dark, setDark }: { dark: boolean; setDark: (v: boolean) => void }) => {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const [active, setActive] = useState("#hero");

  useEffect(() => {
    const fn = () => setScrolled(window.scrollY > 60);
    window.addEventListener("scroll", fn, { passive: true });
    return () => window.removeEventListener("scroll", fn);
  }, []);

  return (
    <header className={`fixed top-0 left-0 right-0 z-[900] transition-all duration-400 ${scrolled ? "glass py-3 shadow-lg shadow-black/10" : "py-5"}`}>
      <nav className="max-w-7xl mx-auto px-6 flex items-center justify-between">
        <a href="#hero" className="flex items-center gap-3">
          <MALogo />
          <span className="font-bold text-foreground hidden sm:block" style={{ fontFamily: "'Outfit',sans-serif" }}>
            Michael Addisu
          </span>
        </a>

        <div className="hidden md:flex items-center gap-8">
          {NAV_LINKS.map(l => (
            <a key={l.label} href={l.href} onClick={() => setActive(l.href)}
              className={`nav-link ${active === l.href ? "active" : ""}`}>{l.label}</a>
          ))}
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => setDark(!dark)} aria-label="Toggle theme"
            className="w-9 h-9 glass rounded-full flex items-center justify-center text-foreground/60 hover:text-foreground transition-colors"
          >
            {dark ? <Sun size={16} /> : <Moon size={16} />}
          </button>
          <a href="#contact" className="btn-primary hidden sm:inline-flex text-sm py-2 px-4">Hire Me</a>
          <button
            onClick={() => setOpen(!open)} aria-label="Toggle menu"
            className="md:hidden w-9 h-9 glass rounded-full flex items-center justify-center text-foreground/60"
          >
            {open ? <X size={18} /> : <Menu size={18} />}
          </button>
        </div>
      </nav>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: "auto" }} exit={{ opacity: 0, height: 0 }}
            className="md:hidden overflow-hidden border-t border-border"
            style={{ background: dark ? "rgba(7,7,18,.95)" : "rgba(255,255,255,.95)", backdropFilter: "blur(20px)" }}
          >
            <div className="max-w-7xl mx-auto px-6 py-4 space-y-1">
              {NAV_LINKS.map(l => (
                <a key={l.label} href={l.href}
                  onClick={() => { setActive(l.href); setOpen(false); }}
                  className="block py-2.5 px-3 rounded-lg text-foreground/70 hover:text-foreground hover:bg-white/5 text-sm font-medium transition-colors">
                  {l.label}
                </a>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
};

// ─── HERO ─────────────────────────────────────────────────────────────────────

const Hero = () => {
  const typed = useTyping(TYPED);
  return (
    <section id="hero" className="relative min-h-screen flex items-center overflow-hidden">
      <div className="hero-glow absolute inset-0" />
      <ParticleCanvas />

      <div className="relative z-10 max-w-7xl mx-auto px-6 py-28 grid md:grid-cols-2 gap-12 items-center w-full">
        {/* Copy */}
        <motion.div initial={{ opacity: 0, x: -40 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1] }}>
          <p className="section-label mb-3">Hello, I'm</p>
          <h1 className="font-bold leading-none mb-3" style={{ fontFamily: "'Outfit',sans-serif", fontSize: "clamp(2.8rem, 8vw, 5.5rem)" }}>
            Michael<br />
            <span className="grad-text">Addisu</span>
          </h1>
          <p className="text-foreground/60 text-lg mb-2">Front-End Developer · Web Developer</p>

          <div className="flex items-center gap-2 h-8 mb-6">
            <span className="text-violet-300 text-base" style={{ fontFamily: "'Outfit',sans-serif" }}>{typed}</span>
            <span className="w-0.5 h-5 bg-violet-400 blink" />
          </div>

          <p className="text-foreground/50 leading-relaxed mb-8 max-w-md">
            A 20-year-old passionate developer from Addis Ababa, Ethiopia — crafting
            beautiful, performant digital experiences with modern web technologies.
          </p>

          <div className="flex flex-wrap gap-3 mb-8">
            <a href="mailto:michaeladdisu@example.com" className="btn-primary">
              <Mail size={15} /> Contact Me
            </a>
            <a href="#" download className="btn-ghost">
              <Download size={15} /> Download CV
            </a>
          </div>

          <div className="flex items-center gap-3">
            {([
              { href: "https://github.com/MichaelAddisu", icon: Github, label: "GitHub" },
              { href: "https://linkedin.com/in/michaeladdisu", icon: Linkedin, label: "LinkedIn" },
              { href: "https://instagram.com/michaeladdisu", icon: Instagram, label: "Instagram" },
            ] as const).map(({ href, icon: Icon, label }) => (
              <a key={label} href={href} target="_blank" rel="noopener noreferrer" aria-label={label}
                className="w-10 h-10 glass rounded-full flex items-center justify-center text-foreground/50 hover:text-violet-400 transition-all duration-300 hover:border-violet-500/30">
                <Icon size={18} />
              </a>
            ))}
            <span className="text-foreground/30 text-sm ml-1">Addis Ababa 🇪🇹</span>
          </div>
        </motion.div>

        {/* Photo */}
        <motion.div
          initial={{ opacity: 0, scale: 0.85 }} animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.7, delay: 0.15, ease: [0.22, 1, 0.36, 1] }}
          className="flex justify-center"
        >
          <div className="relative floating">
            <div className="grad-border rounded-full p-[2px]">
              <div className="w-64 h-64 md:w-80 md:h-80 rounded-full overflow-hidden bg-violet-950/60">
                <img
                  src="https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=500&h=500&fit=crop&auto=format"
                  alt="Michael Addisu — Front-End Developer from Addis Ababa"
                  className="w-full h-full object-cover"
                />
              </div>
            </div>
            {/* Ping rings */}
            <div className="absolute inset-0 rounded-full border border-violet-500/20 ping-slow" />
            {/* Badges */}
            <div className="absolute -bottom-3 -left-6 glass rounded-xl px-3 py-2 text-xs text-foreground/80 flex items-center gap-2 shadow-lg">
              <span className="w-2 h-2 rounded-full bg-emerald-400 shadow-sm shadow-emerald-400" />
              Available for work
            </div>
            <div className="absolute -top-3 -right-4 glass rounded-xl px-3 py-2" style={{ fontFamily: "'JetBrains Mono',monospace", fontSize: ".7rem", color: "#a78bfa" }}>
              2+ yrs exp
            </div>
          </div>
        </motion.div>
      </div>

      <motion.a href="#about" initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 1.6 }}
        className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-1 text-foreground/30 hover:text-foreground/60 transition-colors">
        <span style={{ fontFamily: "'JetBrains Mono',monospace", fontSize: ".68rem", letterSpacing: ".18em" }}>SCROLL</span>
        <ChevronDown size={18} className="animate-bounce" />
      </motion.a>
    </section>
  );
};

// ─── ABOUT ────────────────────────────────────────────────────────────────────

const About = () => (
  <section id="about" className="py-24">
    <div className="max-w-7xl mx-auto px-6">
      <SectionHeader label="About Me" title="Who I Am" desc="Passionate front-end developer with a love for creating beautiful, functional digital experiences." />

      <div className="grid md:grid-cols-2 gap-16 items-start">
        <motion.div variants={stagger} initial="hidden" whileInView="show" viewport={{ once: true }}>
          <motion.h3 variants={fadeUp} className="text-2xl font-bold text-foreground mb-4" style={{ fontFamily: "'Outfit',sans-serif" }}>My Story</motion.h3>
          <motion.p variants={fadeUp} className="text-foreground/55 leading-relaxed mb-4">
            I'm Michael Addisu, a 20-year-old Front-End Developer from Addis Ababa, Ethiopia. My journey started
            with a simple curiosity about how websites work — which quickly evolved into a deep passion for crafting
            exceptional digital experiences.
          </motion.p>
          <motion.p variants={fadeUp} className="text-foreground/55 leading-relaxed mb-8">
            I specialize in building beautiful, responsive, and performant web applications using modern technologies
            like React and TypeScript. Every line of code I write is driven by a commitment to quality, accessibility,
            and outstanding user experience.
          </motion.p>

          <motion.div variants={stagger} className="grid grid-cols-2 gap-3">
            {([
              { label: "Mission", text: "Deliver exceptional digital experiences" },
              { label: "Vision", text: "Shape Ethiopia's digital future" },
              { label: "Values", text: "Quality, creativity & integrity" },
              { label: "Goal", text: "World-class developer & innovator" },
            ]).map(v => (
              <motion.div key={v.label} variants={fadeUp} className="glass-card p-4">
                <p className="section-label mb-1">{v.label}</p>
                <p className="text-foreground/70 text-sm">{v.text}</p>
              </motion.div>
            ))}
          </motion.div>
        </motion.div>

        {/* Timeline */}
        <motion.div variants={stagger} initial="hidden" whileInView="show" viewport={{ once: true }}>
          <motion.h3 variants={fadeUp} className="text-2xl font-bold text-foreground mb-8" style={{ fontFamily: "'Outfit',sans-serif" }}>My Journey</motion.h3>
          <div className="space-y-0">
            {TIMELINE_DATA.map((item, i) => (
              <motion.div key={i} variants={fadeUp} className="flex gap-5">
                <div className="flex flex-col items-center">
                  <div className="tl-dot" />
                  {i < TIMELINE_DATA.length - 1 && <div className="timeline-line" />}
                </div>
                <div className={`pb-8 ${i === TIMELINE_DATA.length - 1 ? "" : ""}`}>
                  <p className="section-label mb-1">{item.year}</p>
                  <h4 className="font-semibold text-foreground mb-1" style={{ fontFamily: "'Outfit',sans-serif" }}>{item.title}</h4>
                  <p className="text-foreground/50 text-sm leading-relaxed">{item.desc}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </div>
  </section>
);

// ─── SKILLS ───────────────────────────────────────────────────────────────────

const SkillBar = ({ name, pct, vis }: { name: string; pct: number; vis: boolean }) => (
  <div>
    <div className="flex justify-between mb-1.5">
      <span className="text-foreground/80 text-sm font-medium">{name}</span>
      <span className="text-violet-400 text-xs" style={{ fontFamily: "'JetBrains Mono',monospace" }}>{pct}%</span>
    </div>
    <div className="skill-bar">
      <div className="skill-fill" style={{ width: vis ? `${pct}%` : "0%" }} />
    </div>
  </div>
);

const Skills = () => {
  const { ref, vis } = useInView(0.15);
  return (
    <section id="skills" className="py-24">
      <div className="max-w-7xl mx-auto px-6">
        <SectionHeader label="Skills" title="My Expertise" desc="Technologies and tools I use to bring ideas to life — from pixel to production." />
        <div ref={ref} className="grid md:grid-cols-3 gap-6">
          {Object.entries(SKILLS_DATA).map(([cat, skills], i) => (
            <motion.div key={cat} variants={fadeUp} initial="hidden" whileInView="show" viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className="glass-card p-6"
            >
              <div className="flex items-center gap-2 mb-6">
                <div className="w-7 h-7 rounded-lg flex items-center justify-center" style={{ background: "rgba(124,58,237,.15)" }}>
                  <Code2 size={14} className="text-violet-400" />
                </div>
                <h3 className="font-semibold text-foreground" style={{ fontFamily: "'Outfit',sans-serif" }}>{cat}</h3>
              </div>
              <div className="space-y-4">
                {skills.map(s => <SkillBar key={s.name} name={s.name} pct={s.pct} vis={vis} />)}
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

// ─── PROJECTS ─────────────────────────────────────────────────────────────────

const ProjectCard = ({ p }: { p: typeof PROJECTS_DATA[0] }) => (
  <motion.div variants={fadeUp} initial="hidden" whileInView="show" viewport={{ once: true }}
    className="glass-card overflow-hidden group proj-card">
    <div className="overflow-hidden relative h-[200px] bg-violet-950/40">
      <img src={p.img} alt={p.title} className="proj-img" loading="lazy" />
      <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end p-4 gap-2">
        <a href={p.github} target="_blank" rel="noopener noreferrer"
          className="btn-ghost py-1.5 px-3 text-xs rounded-lg !gap-1">
          <Github size={12} /> Code
        </a>
        <a href={p.demo} target="_blank" rel="noopener noreferrer"
          className="btn-primary py-1.5 px-3 text-xs rounded-lg !gap-1">
          <Eye size={12} /> Demo
        </a>
      </div>
    </div>
    <div className="p-5">
      <h3 className="font-semibold text-foreground text-lg mb-2 leading-snug" style={{ fontFamily: "'Outfit',sans-serif" }}>{p.title}</h3>
      <p className="text-foreground/50 text-sm leading-relaxed mb-4">{p.desc}</p>
      <div className="flex flex-wrap gap-1.5 mb-4">
        {p.tech.map(t => <span key={t} className="tag">{t}</span>)}
      </div>
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-1 text-yellow-400 text-xs" style={{ fontFamily: "'JetBrains Mono',monospace" }}>
          <Star size={12} fill="currentColor" /> {p.stars}
        </div>
        <div className="flex gap-3">
          <a href={p.github} target="_blank" rel="noopener noreferrer" className="text-foreground/30 hover:text-foreground/70 transition-colors"><Github size={15} /></a>
          <a href={p.demo} target="_blank" rel="noopener noreferrer" className="text-foreground/30 hover:text-violet-400 transition-colors"><ExternalLink size={15} /></a>
        </div>
      </div>
    </div>
  </motion.div>
);

const Projects = () => {
  const [q, setQ] = useState("");
  const [cat, setCat] = useState("All");
  const filtered = PROJECTS_DATA.filter(p =>
    (cat === "All" || p.cat === cat) &&
    (p.title.toLowerCase().includes(q.toLowerCase()) || p.desc.toLowerCase().includes(q.toLowerCase()))
  );

  return (
    <section id="projects" className="py-24">
      <div className="max-w-7xl mx-auto px-6">
        <SectionHeader label="Portfolio" title="My Projects" desc="A selection of projects that showcase my passion for building elegant, functional web experiences." />

        <div className="flex flex-col sm:flex-row gap-4 mb-10">
          <div className="relative flex-1">
            <Search size={15} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-foreground/35 pointer-events-none" />
            <input value={q} onChange={e => setQ(e.target.value)} placeholder="Search projects..." className="contact-input pl-10" />
          </div>
          <div className="flex gap-2 flex-wrap">
            {CATS.map(c => (
              <button key={c} onClick={() => setCat(c)}
                className={`px-4 py-2 rounded-xl text-sm font-medium transition-all duration-200 ${cat === c ? "bg-violet-600 text-white shadow-lg shadow-violet-600/25" : "glass text-foreground/60 hover:text-foreground"}`}
                style={{ fontFamily: "'Outfit',sans-serif" }}>
                {c}
              </button>
            ))}
          </div>
        </div>

        {filtered.length > 0 ? (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filtered.map(p => <ProjectCard key={p.id} p={p} />)}
          </div>
        ) : (
          <div className="text-center py-20 text-foreground/35">
            <Search size={44} className="mx-auto mb-4 opacity-30" />
            <p>No projects match your search.</p>
          </div>
        )}
      </div>
    </section>
  );
};

// ─── SERVICES ─────────────────────────────────────────────────────────────────

const Services = () => (
  <section id="services" className="py-24">
    <div className="max-w-7xl mx-auto px-6">
      <SectionHeader label="Services" title="What I Offer" desc="Comprehensive web development services to help bring your vision to reality." />
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {SERVICES_DATA.map((s, i) => (
          <motion.div key={s.title} variants={fadeUp} initial="hidden" whileInView="show" viewport={{ once: true }}
            transition={{ delay: i * 0.07 }} className="glass-card p-6 group">
            <div className="w-12 h-12 rounded-xl flex items-center justify-center mb-4 transition-colors group-hover:bg-violet-500/20"
              style={{ background: "rgba(124,58,237,.1)", border: "1px solid rgba(124,58,237,.2)" }}>
              <s.icon size={22} className="text-violet-400" />
            </div>
            <h3 className="font-semibold text-foreground text-lg mb-2" style={{ fontFamily: "'Outfit',sans-serif" }}>{s.title}</h3>
            <p className="text-foreground/50 text-sm leading-relaxed">{s.desc}</p>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);

// ─── STATS ────────────────────────────────────────────────────────────────────

const StatCard = ({ s, active }: { s: typeof STATS_DATA[0]; active: boolean }) => {
  const n = useCounter(s.val, active);
  return (
    <div className="glass-card p-8 text-center">
      <div className="w-14 h-14 rounded-2xl flex items-center justify-center mx-auto mb-4"
        style={{ background: "rgba(124,58,237,.1)", border: "1px solid rgba(124,58,237,.18)" }}>
        <s.icon size={24} className="text-violet-400" />
      </div>
      <p className="grad-text font-bold mb-2" style={{ fontFamily: "'Outfit',sans-serif", fontSize: "3rem", lineHeight: 1 }}>
        {n}{s.suffix}
      </p>
      <p className="text-foreground/50 text-sm">{s.label}</p>
    </div>
  );
};

const Stats = () => {
  const { ref, vis } = useInView(0.3);
  return (
    <section className="py-24 relative overflow-hidden">
      <div className="absolute inset-0" style={{ background: "radial-gradient(ellipse at center, rgba(124,58,237,.07) 0%, transparent 70%)" }} />
      <div className="max-w-7xl mx-auto px-6" ref={ref}>
        <SectionHeader label="Impact" title="By The Numbers" />
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {STATS_DATA.map(s => <StatCard key={s.label} s={s} active={vis} />)}
        </div>
      </div>
    </section>
  );
};

// ─── TESTIMONIALS ─────────────────────────────────────────────────────────────

const Testimonials = () => {
  const [idx, setIdx] = useState(0);
  const pairs = [[0, 1], [2, 3]];

  return (
    <section id="testimonials" className="py-24">
      <div className="max-w-7xl mx-auto px-6">
        <SectionHeader label="Testimonials" title="What Clients Say" desc="Feedback from people who trusted me to build their digital presence." />

        <AnimatePresence mode="wait">
          <motion.div key={idx}
            initial={{ opacity: 0, x: 30 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -30 }}
            transition={{ duration: 0.4 }}
            className="grid md:grid-cols-2 gap-6 mb-8">
            {pairs[idx].map(ti => {
              const t = TESTIMONIALS_DATA[ti];
              return (
                <div key={t.name} className="glass-card p-6">
                  <div className="flex gap-1 mb-4">
                    {Array.from({ length: t.rating }).map((_, i) => (
                      <Star key={i} size={14} className="text-yellow-400" fill="currentColor" />
                    ))}
                  </div>
                  <p className="text-foreground/65 leading-relaxed mb-6 italic text-sm">"{t.text}"</p>
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full flex items-center justify-center text-white font-bold text-sm"
                      style={{ background: "linear-gradient(135deg,#7c3aed,#22d3ee)" }}>
                      {t.avatar}
                    </div>
                    <div>
                      <p className="font-semibold text-foreground text-sm" style={{ fontFamily: "'Outfit',sans-serif" }}>{t.name}</p>
                      <p className="text-foreground/40 text-xs">{t.role}</p>
                    </div>
                  </div>
                </div>
              );
            })}
          </motion.div>
        </AnimatePresence>

        <div className="flex justify-center gap-2">
          {[0, 1].map(i => (
            <button key={i} onClick={() => setIdx(i)}
              className="rounded-full transition-all duration-300"
              style={{ width: idx === i ? 28 : 8, height: 8, background: idx === i ? "#7c3aed" : "rgba(255,255,255,.15)" }}
              aria-label={`Slide ${i + 1}`}
            />
          ))}
        </div>
      </div>
    </section>
  );
};

// ─── BLOG ─────────────────────────────────────────────────────────────────────

const Blog = () => (
  <section id="blog" className="py-24">
    <div className="max-w-7xl mx-auto px-6">
      <SectionHeader label="Blog" title="Latest Articles" desc="Thoughts on web development, design, and building for the modern web." />
      <div className="grid md:grid-cols-3 gap-6">
        {BLOG_DATA.map((post, i) => (
          <motion.article key={post.title} variants={fadeUp} initial="hidden" whileInView="show" viewport={{ once: true }}
            transition={{ delay: i * 0.1 }}
            className="glass-card overflow-hidden group cursor-pointer">
            <div className="overflow-hidden h-48 bg-violet-950/40">
              <img src={post.img} alt={post.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" loading="lazy" />
            </div>
            <div className="p-5">
              <span className="tag mb-3 inline-block">{post.cat}</span>
              <h3 className="font-semibold text-foreground mb-3 leading-snug group-hover:text-violet-400 transition-colors"
                style={{ fontFamily: "'Outfit',sans-serif" }}>{post.title}</h3>
              <div className="flex items-center justify-between text-foreground/35 text-xs"
                style={{ fontFamily: "'JetBrains Mono',monospace" }}>
                <span>{post.date}</span>
                <span>{post.read} read</span>
              </div>
            </div>
          </motion.article>
        ))}
      </div>
    </div>
  </section>
);

// ─── CONTACT ─────────────────────────────────────────────────────────────────

const Contact = () => {
  const [form, setForm] = useState({ name: "", email: "", message: "" });
  const [sent, setSent] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const mailto = `mailto:michaeladdisu@example.com?subject=Portfolio Inquiry from ${encodeURIComponent(form.name)}&body=${encodeURIComponent(form.message)}`;
    window.location.href = mailto;
    setSent(true);
    setTimeout(() => setSent(false), 4000);
  };

  const CONTACT_LINKS = [
    { icon: Mail, label: "Email", value: "michaeladdisu@example.com", href: "mailto:michaeladdisu@example.com" },
    { icon: Phone, label: "Phone", value: "+251 9XX XXX XXX", href: "tel:+2519XXXXXXXX" },
    { icon: MessageCircle, label: "WhatsApp", value: "Chat on WhatsApp", href: "https://wa.me/2519XXXXXXXX" },
    { icon: MapPin, label: "Location", value: "Addis Ababa, Ethiopia", href: "https://maps.google.com/?q=Addis+Ababa+Ethiopia" },
  ];

  return (
    <section id="contact" className="py-24">
      <div className="max-w-7xl mx-auto px-6">
        <SectionHeader label="Contact" title="Get In Touch"
          desc="Have a project in mind? Let's work together to create something amazing." />

        <div className="grid md:grid-cols-2 gap-12">
          {/* Info */}
          <motion.div variants={fadeUp} initial="hidden" whileInView="show" viewport={{ once: true }}>
            <h3 className="text-2xl font-bold text-foreground mb-4" style={{ fontFamily: "'Outfit',sans-serif" }}>Let's Connect</h3>
            <p className="text-foreground/55 leading-relaxed mb-8">
              I'm always open to discussing new projects, creative ideas, or opportunities to be part of amazing things.
            </p>

            <div className="space-y-3 mb-8">
              {CONTACT_LINKS.map(item => (
                <a key={item.label} href={item.href}
                  target={item.label !== "Email" && item.label !== "Phone" ? "_blank" : undefined}
                  rel="noopener noreferrer"
                  className="flex items-center gap-4 glass-card p-4 group hover:!transform-none" style={{ transition: "border-color .25s, box-shadow .25s" }}>
                  <div className="w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0 group-hover:bg-violet-500/20 transition-colors"
                    style={{ background: "rgba(124,58,237,.1)", border: "1px solid rgba(124,58,237,.18)" }}>
                    <item.icon size={17} className="text-violet-400" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-foreground/40 text-xs mb-0.5" style={{ fontFamily: "'JetBrains Mono',monospace", letterSpacing: ".08em" }}>{item.label}</p>
                    <p className="text-foreground/80 text-sm truncate">{item.value}</p>
                  </div>
                  <ArrowRight size={15} className="text-foreground/20 group-hover:text-violet-400 transition-colors flex-shrink-0" />
                </a>
              ))}
            </div>

            <div className="flex gap-3">
              {([
                { href: "https://github.com/MichaelAddisu", icon: Github, label: "GitHub" },
                { href: "https://linkedin.com/in/michaeladdisu", icon: Linkedin, label: "LinkedIn" },
                { href: "https://instagram.com/michaeladdisu", icon: Instagram, label: "Instagram" },
              ] as const).map(({ href, icon: Icon, label }) => (
                <a key={label} href={href} target="_blank" rel="noopener noreferrer" aria-label={label}
                  className="w-10 h-10 glass rounded-full flex items-center justify-center text-foreground/50 hover:text-violet-400 transition-all duration-300 hover:border-violet-500/30">
                  <Icon size={17} />
                </a>
              ))}
            </div>
          </motion.div>

          {/* Form */}
          <motion.form variants={fadeUp} initial="hidden" whileInView="show" viewport={{ once: true }}
            onSubmit={handleSubmit} className="glass-card p-8 space-y-5">
            <div>
              <label className="block text-foreground/55 text-sm mb-2">Your Name</label>
              <input value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))}
                placeholder="Michael Addisu" required className="contact-input" />
            </div>
            <div>
              <label className="block text-foreground/55 text-sm mb-2">Email Address</label>
              <input type="email" value={form.email} onChange={e => setForm(f => ({ ...f, email: e.target.value }))}
                placeholder="you@example.com" required className="contact-input" />
            </div>
            <div>
              <label className="block text-foreground/55 text-sm mb-2">Message</label>
              <textarea value={form.message} onChange={e => setForm(f => ({ ...f, message: e.target.value }))}
                placeholder="Tell me about your project..." rows={5} required className="contact-input resize-none" />
            </div>
            <button type="submit" className="btn-primary w-full justify-center">
              {sent ? <><CheckCircle size={15} /> Message Sent!</> : <><Send size={15} /> Send Message</>}
            </button>
          </motion.form>
        </div>
      </div>
    </section>
  );
};

// ─── FOOTER ───────────────────────────────────────────────────────────────────

const Footer = () => (
  <footer className="border-t border-border py-14">
    <div className="max-w-7xl mx-auto px-6">
      <div className="grid md:grid-cols-4 gap-10 mb-10">
        <div className="md:col-span-2">
          <div className="flex items-center gap-3 mb-4">
            <MALogo />
            <div>
              <p className="font-bold text-foreground" style={{ fontFamily: "'Outfit',sans-serif" }}>Michael Addisu</p>
              <p className="text-foreground/40 text-xs" style={{ fontFamily: "'JetBrains Mono',monospace" }}>Front-End Developer</p>
            </div>
          </div>
          <p className="text-foreground/45 text-sm leading-relaxed max-w-xs">
            Building beautiful digital experiences from Addis Ababa, Ethiopia. Open to collaboration and new opportunities.
          </p>
        </div>
        <div>
          <h4 className="font-semibold text-foreground mb-4 text-sm" style={{ fontFamily: "'Outfit',sans-serif" }}>Quick Links</h4>
          <div className="space-y-2">
            {["About", "Skills", "Projects", "Services", "Contact"].map(l => (
              <a key={l} href={`#${l.toLowerCase()}`} className="block text-foreground/40 hover:text-foreground/80 text-sm transition-colors">
                {l}
              </a>
            ))}
          </div>
        </div>
        <div>
          <h4 className="font-semibold text-foreground mb-4 text-sm" style={{ fontFamily: "'Outfit',sans-serif" }}>Connect</h4>
          <div className="space-y-2">
            {[
              { label: "GitHub", href: "https://github.com/MichaelAddisu" },
              { label: "LinkedIn", href: "https://linkedin.com/in/michaeladdisu" },
              { label: "Instagram", href: "https://instagram.com/michaeladdisu" },
              { label: "Email", href: "mailto:michaeladdisu@example.com" },
            ].map(s => (
              <a key={s.label} href={s.href} target="_blank" rel="noopener noreferrer"
                className="block text-foreground/40 hover:text-foreground/80 text-sm transition-colors">{s.label}</a>
            ))}
          </div>
        </div>
      </div>
      <div className="border-t border-border pt-6 flex flex-col sm:flex-row items-center justify-between gap-4">
        <p className="text-foreground/30 text-sm">© 2025 Michael Addisu. All rights reserved.</p>
        <button
          onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
          aria-label="Back to top"
          className="w-10 h-10 glass rounded-full flex items-center justify-center text-foreground/50 hover:text-violet-400 hover:border-violet-500/30 transition-all duration-300">
          <ArrowUp size={17} />
        </button>
      </div>
    </div>
  </footer>
);

// ─── APP ──────────────────────────────────────────────────────────────────────

export default function App() {
  const [loading, setLoading] = useState(true);
  const [dark, setDark] = useState(true);

  useEffect(() => {
    if (dark) document.documentElement.classList.add("dark");
    else document.documentElement.classList.remove("dark");
  }, [dark]);

  return (
    <>
      <style dangerouslySetInnerHTML={{ __html: STYLES }} />
      <AnimatePresence>{loading && <Loader key="loader" onDone={() => setLoading(false)} />}</AnimatePresence>

      {!loading && (
        <div className="bg-background text-foreground min-h-screen">
          <CustomCursor />
          <ScrollProgress />
          <Navbar dark={dark} setDark={setDark} />
          <main>
            <Hero />
            <About />
            <Skills />
            <Projects />
            <Services />
            <Stats />
            <Testimonials />
            <Blog />
            <Contact />
          </main>
          <Footer />
        </div>
      )}
    </>
  );
}
